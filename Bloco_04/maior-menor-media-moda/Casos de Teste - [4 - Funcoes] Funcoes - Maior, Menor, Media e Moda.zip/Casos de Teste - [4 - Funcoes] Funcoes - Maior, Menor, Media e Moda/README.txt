Arquivo zip gerado em: 27/07/2021 18:57:19 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [4 - Funções] Funções - Maior, Menor, Média e Moda