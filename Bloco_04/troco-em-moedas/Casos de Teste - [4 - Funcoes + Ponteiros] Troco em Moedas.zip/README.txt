Arquivo zip gerado em: 19/12/2021 15:36:20 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [4 - Funções + Ponteiros] Troco em Moedas