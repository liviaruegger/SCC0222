Arquivo zip gerado em: 28/07/2021 11:07:57 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [6 - Struct] Pokedex