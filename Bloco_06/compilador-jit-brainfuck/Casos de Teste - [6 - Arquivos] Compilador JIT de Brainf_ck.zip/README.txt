Arquivo zip gerado em: 28/07/2021 14:50:31 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [6 - Arquivos] Compilador JIT de Brainf*ck