Arquivo zip gerado em: 30/07/2021 14:42:05 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [7 - Recursão] Calculadora LISP (extra)