Arquivo zip gerado em: 19/12/2021 14:54:25 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Repetição] Progressão Aritmética