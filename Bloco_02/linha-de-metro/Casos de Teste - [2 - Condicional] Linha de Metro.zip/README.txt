Arquivo zip gerado em: 18/12/2021 22:25:20 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Condicional] Linha de Metrô