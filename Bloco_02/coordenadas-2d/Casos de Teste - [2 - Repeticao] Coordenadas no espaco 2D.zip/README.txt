Arquivo zip gerado em: 19/12/2021 14:49:53 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Repetição] Coordenadas no espaço 2D