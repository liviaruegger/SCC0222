Arquivo zip gerado em: 19/12/2021 11:47:25 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Condicional] Ano Bissexto